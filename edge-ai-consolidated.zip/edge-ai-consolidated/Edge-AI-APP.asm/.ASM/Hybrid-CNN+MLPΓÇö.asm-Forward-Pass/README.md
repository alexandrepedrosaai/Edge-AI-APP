# Hybrid CNN + MLP — .asm Forward Pass

**Tag:** `Hybrid-CNN+MLP—.asm-Forward-Pass`

## Description



## What's Changed
* Co-authored-by Edge <support@edge.network> by @alexandrepedrosaai in https://github.com/alexandrepedrosaai/Edge-AI-APP/pull/1
* Co-authored-by: Edge <support@edge.network> by @alexandrepedrosaai in https://github.com/alexandrepedrosaai/Edge-AI-APP/pull/2
* Co-authored-by:  Microsoft <opensource@microsoft.com> by @alexandrepedrosaai in https://github.com/alexandrepedrosaai/Edge-AI-APP/pull/3
* Co-authored-by:  Microsoft <opensource@microsoft.com> by @alexandrepedrosaai...

## Files

- `Hybrid-CNN+MLP—.asm-Forward-Pass.asm` - Extracted ASM code from this release
